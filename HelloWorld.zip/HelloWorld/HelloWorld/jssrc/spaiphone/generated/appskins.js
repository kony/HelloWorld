function skinsInit() {
    CopyslButtonGlossBlue003f32005c39646 = "CopyslButtonGlossBlue003f32005c39646";
    CopyslForm005c3d2dd737745 = "CopyslForm005c3d2dd737745";
    CopyslLabel0a56f874d63754e = "CopyslLabel0a56f874d63754e";
    slButtonGlossBlue = "slButtonGlossBlue";
    slButtonGlossRed = "slButtonGlossRed";
    slDynamicNotificationForm = "slDynamicNotificationForm";
    slFbox = "slFbox";
    slForm = "slForm";
    slImage = "slImage";
    slLabel = "slLabel";
    slPopup = "slPopup";
    slStaticNotificationForm = "slStaticNotificationForm";
    slTitleBar = "slTitleBar";
    slWatchForm = "slWatchForm";
};