//actions.js file 
function AS_Button_ecf7b89d9ad4400fb9b522faa13982f5(eventobject) {
    return showPopup.call(this);
}