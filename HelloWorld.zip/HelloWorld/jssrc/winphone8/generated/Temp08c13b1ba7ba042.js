function initializeTemp08c13b1ba7ba042() {
    FlexContainer06e658e92ddef44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "FlexContainer06e658e92ddef44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0e84c38ffb51b45"
    }, {}, {});
    FlexContainer06e658e92ddef44.setDefaultUnit(kony.flex.DP);
    var Label01238ca54d56c46 = new kony.ui.Label({
        "height": "100%",
        "id": "Label01238ca54d56c46",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0fdabaf6c42e74d",
        "text": "Label",
        "top": "1dp",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer06e658e92ddef44.add(
    Label01238ca54d56c46);
}