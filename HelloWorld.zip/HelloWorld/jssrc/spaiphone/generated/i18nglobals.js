kony.globals["appid"] = "HelloWorld";
kony.globals["locales"] = [];